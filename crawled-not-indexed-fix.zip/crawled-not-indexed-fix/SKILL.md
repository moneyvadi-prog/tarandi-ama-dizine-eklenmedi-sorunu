---
name: crawled-not-indexed-fix
description: Google Search Console'da "Tarandı ama dizine eklenmedi" (Crawled - currently not indexed) uyarısı alan sayfalar için sistematik teşhis ve teknik SEO çözüm planı üretir. Sorunun kök nedenini render, içerik kalitesi, meta yapı, robots/noindex, hreflang, iç linkleme ve site hızı ekseninde tanılar; her sayfa için önceliklendirilmiş aksiyon listesi ve düzeltme sonrası doğrulama protokolü çıkarır. Kullanıcı "tarandı ama dizine eklenmedi", "indexlenmiyor", "dizine eklenmedi", "crawled not indexed", "GSC index sorunu", "sayfam indexte yok", "URL Inspection", "render sorunu", "JS render index", "noindex problemi" gibi taleplerde tetiklenir.
---

# Tarandı Ama Dizine Eklenmedi — Teknik SEO Çözüm Planı

Bu Skill, Google Search Console'da **"Tarandı ama dizine eklenmedi" (Crawled - currently not indexed)** uyarısı alan sayfalar için sistematik bir **teşhis → öncelik → çözüm → doğrulama** akışı üretir.

Sorun tek bir nedenden değil, genellikle **render, içerik kalitesi, teknik direktifler, iç linkleme ve site hızı** eksenlerinden bir veya birkaçının üst üste gelmesinden kaynaklanır. Bu Skill, kullanıcıdan aldığı bilgiyle nedeni daraltır ve her sayfa için uygulanabilir bir aksiyon planı çıkarır.

## Ne Zaman Kullanılır

Bu Skill aşağıdaki durumlarda devreye girer:

* Search Console'da "Crawled - currently not indexed" / "Tarandı ama dizine eklenmedi" uyarısı alındığında
* Bir veya daha fazla sayfa Googlebot tarafından taranmış ama indekse alınmamışsa
* Yeni yayınlanan içerikler aylardır indexlenmiyorsa
* JavaScript ağırlıklı sitelerde (Next.js, React, Vue, Angular, SPA) sayfalar görünür olduğu halde indekste yoksa
* Çok dilli sitelerde belirli dil versiyonları indekslenmiyorsa
* E-ticaret/blog/kurumsal sitelerde belirli kategoriler veya URL paternleri indekslenmiyorsa

**Uygun DEĞİL:**
* "Discovered - currently not indexed" (henüz taranmamış) — bu farklı bir sorundur, crawl tetikleme gerekir
* "Page with redirect" / "Soft 404" / "Server error" durumları — bunlar farklı çözüm akışları gerektirir
* `noindex` etiketi bilinçli konulmuş sayfalar (admin, sepet, login)

## Soruna Yaklaşım: 6 Eksenli Teşhis

"Tarandı ama dizine eklenmedi" uyarısı tek bir sebepten değil, aşağıdaki 6 eksenden biri veya birkaçından kaynaklanır. Skill, her ekseni sırayla kontrol eder:

1. **Render Ekseni** — Googlebot içeriği gerçekten "görüyor" mu?
2. **İçerik Kalitesi Ekseni** — Sayfa Google için "indexlemeye değer" mi?
3. **Meta & Direktif Ekseni** — Yanlışlıkla index engelleniyor mu?
4. **Yapısal Ekseni** — Sayfa siteye nasıl bağlı? (iç linkleme, sitemap)
5. **Çok Dilli & Kanonik Ekseni** — hreflang/canonical kafa karışıklığı var mı?
6. **Performans Ekseni** — Tarama bütçesi ve render süresi ne durumda?

## Skill Akışı

Kullanıcı sorunu getirdiğinde aşağıdaki aşamaları **sırayla** uygula. Bir aşamayı tamamlamadan sonrakine geçme.

### Aşama 0: Bilgi Toplama

Kullanıcıya şu sırayla sor (henüz vermediyse):

1. **Etkilenen URL veya URL paterni nedir?** (örn. tek bir sayfa mı, /blog/* gibi bir patern mi, tüm site mi)
2. **Site teknolojisi nedir?** (WordPress, Next.js, React SPA, Shopify, Webflow, custom)
3. **Sayfa ne zaman yayınlandı, ne zaman crawl edildi?** (Search Console > URL Inspection'dan görülebilir)
4. **Sorun kaç sayfayı etkiliyor?** (1-5, 5-50, 50-500, 500+)
5. **Site yaşı ve domain otoritesi tahmini?** (yeni site / 1-3 yaş / eski / yüksek otorite)
6. **Daha önce hangi düzeltmeler denendi?** (tekrar gönderme, içerik güncelleme, vs.)

Bu bilgiler eksikse devam etme — eksik bilgiyle yapılan teşhis yanlış aksiyona yol açar.

### Aşama 1: Render Ekseni Teşhisi

**Sorulacaklar / Kontrol edilecekler:**

* Site SSR (Server-Side Rendering) mı, CSR (Client-Side Rendering) mı, SSG (Static) mı?
* Search Console > URL Inspection > "Test Live URL" > "View tested page" > Screenshot ve HTML'de **gerçek içerik görünüyor mu**?
* "More Info" sekmesinde **JavaScript console errors** var mı?
* HTML kaynağında (`view-source:`) ana içerik var mı, yoksa sadece `<div id="root"></div>` mı görünüyor?

**Karar matrisi:**

| Durum | Tanı | Çözüm |
|---|---|---|
| HTML'de içerik yok, sadece JS bundle | Pure CSR — Googlebot içeriği geç görüyor veya görmüyor | SSR/SSG'ye geçiş zorunlu |
| HTML'de kısmi içerik var ama lazy-loaded | Hibrit render, kritik içerik aşağıda | Critical content'i SSR ile ver |
| HTML'de içerik var ama URL Inspection screenshot boş | Render queue gecikmesi veya JS error | Console error fix + render budget azaltma |
| HTML'de içerik tam | Render sorun değil, başka eksene geç | Aşama 2'ye geç |

**Next.js spesifik çözüm önerileri:**
* Sayfanın başına: `export const dynamic = 'force-static';` veya `export const dynamic = 'error';`
* Dinamik veriye ihtiyaç varsa: `export const revalidate = 3600;` (ISR)
* `generateStaticParams` ile tüm dinamik route'ları önceden render et

### Aşama 2: İçerik Kalitesi Ekseni Teşhisi

Google "düşük değerli" gördüğü içerikleri bilinçli olarak **tarayıp indekslemez**. Bu en yaygın sebeplerden biridir.

**Kontrol edilecekler:**

* Sayfa kelime sayısı kaç? (300 kelime altı **risk altında**)
* İçerik **özgün** mü, **scraped/AI-generated/template** mı?
* Aynı sitede **benzer içerikler** var mı? (near-duplicate)
* Sayfanın **özgün değer önerisi** ne? (Google bu sayfayı indekslerse okuyucu için ek değer var mı?)
* Başlık/H1 ile içerik gerçekten örtüşüyor mu?
* Sayfada gerçek bilgi mi var, yoksa **thin content / boilerplate** mi?

**Kırmızı bayraklar (yüksek olasılıkla bu yüzden indexlenmiyor):**
* < 300 kelime ve özgün veri/görüş içermeyen sayfa
* AI ile toplu üretilmiş, edit edilmemiş içerik
* Şablonik kategori sayfası (sadece ürün listesi, açıklama yok)
* Aynı içeriğin küçük varyasyonları (X şehir + hizmet kombinasyonları)
* Outdated içerik (3+ yaş, güncel olmayan veriler)

**Çözüm öncelikleri:**
1. İçeriği **somut bilgi/örnek/veri/görsel** ile zenginleştir (min 600-800 kelime, niş bağımlı)
2. H1 ve ilk paragrafa hedef intent'i net yerleştir
3. Eğer near-duplicate varsa **konsolide et** (canonical veya 301 redirect)
4. Thin kategori sayfalarına özgün introduction + FAQ ekle

### Aşama 3: Meta & Direktif Ekseni Teşhisi

Bazen sorun çok basittir: yanlışlıkla index engellenmiştir.

**Kontrol edilecekler:**

* `<meta name="robots" content="noindex">` var mı? (özellikle staging'den prod'a taşırken unutulan tag)
* HTTP başlığında `X-Robots-Tag: noindex` dönülüyor mu?
* `robots.txt`'de `Disallow:` ile sayfa engellenmiş mi? (Engellenirse zaten taranmaz, ama bazen yanlışlıkla `Allow` paterni eksik kalır)
* Canonical tag başka bir sayfaya işaret ediyor mu? (kendine canonical olmalı veya doğru hedefe)
* Title boş veya generic mi? ("Untitled", "Home", "Page")
* Meta description eksik mi? (Google için zayıf sinyal)
* `<title>` tagi tüm sayfalarda **birebir aynı** mı?

**Hızlı kontrol komutları:**
```bash
# Sayfanın HTTP başlıklarını kontrol et
curl -I https://site.com/page

# X-Robots-Tag var mı?
curl -I https://site.com/page | grep -i x-robots

# robots.txt kontrolü
curl https://site.com/robots.txt
```

### Aşama 4: Yapısal Eksen Teşhisi (İç Linkleme & Sitemap)

Google için bir sayfa **siteye ne kadar bağlıysa** o kadar değerli görünür. "Yetim sayfa" (orphan page) indekslenme şansı düşüktür.

**Kontrol edilecekler:**

* Etkilenen sayfaya **kaç içeriden link** var? (3'ten az **risk**)
* Linkler **menü/footer** mi, yoksa **contextual (içerik içi)** mi? (Contextual link daha güçlü sinyal)
* Sayfa **ana sayfadan kaç tık uzakta**? (3+ derin = risk)
* Sayfa XML sitemap'te var mı?
* Sitemap güncel mi, son değişiklik tarihi doğru mu?

**Çözümler:**
1. Etkilenen sayfaya **en az 3 içerik içi düz metin link** ver (alakalı yüksek otoriteli sayfalardan)
2. Ana sayfadan veya kategori hub'ından **direkt link** ekle
3. Sitemap'i yeniden oluştur ve Search Console'a manuel submit et
4. Eğer sayfa için **breadcrumb** yoksa ekle (yapı sinyalini güçlendirir)

### Aşama 5: Çok Dilli & Kanonik Eksen Teşhisi

Çok dilli sitelerde ve query parametreli URL'lerde bu eksen sıkça suçludur.

**Kontrol edilecekler:**

* hreflang etiketleri var mı, **karşılıklı (reciprocal)** mı?
* `x-default` tanımlı mı?
* Canonical etiketi farklı bir dile mi gidiyor? (örn. /tr/page → /en/page kanonik)
* URL'de gereksiz query parametresi var mı? (?utm=, ?ref=)
* Aynı içerik birden fazla URL'de mi servis ediliyor? (www/non-www, http/https, trailing slash)

**Doğru hreflang örneği:**

```html
<link rel="alternate" hreflang="tr" href="https://site.com/tr/sayfa" />
<link rel="alternate" hreflang="en" href="https://site.com/en/page" />
<link rel="alternate" hreflang="x-default" href="https://site.com/en/page" />
```

Her dil versiyonunun kendi sayfasında **tüm dillerin** hreflang'i bulunmalı (reciprocal).

### Aşama 6: Performans Eksen Teşhisi

Tarama bütçesi yetersiz veya render zinciri uzun sitelerde Googlebot sayfayı görür ama "indekslemeye değecek kadar hızlı olgunlaşmıyor" diye bekletir.

**Kontrol edilecekler:**

* PageSpeed Insights skoru (mobile) — 50 altı risk
* LCP (Largest Contentful Paint) — 4 saniye üstü risk
* TBT (Total Blocking Time) — 600ms üstü risk
* Render-blocking JavaScript var mı?
* Görseller optimize mi (WebP/AVIF, lazy load)?
* CDN kullanılıyor mu?
* Search Console > Crawl Stats > "Average response time" — 1 saniye üstüyse risk

**Çözüm öncelikleri:**
1. Gereksiz async/defer JS'leri kaldır veya geciktir
2. Critical CSS inline et
3. Görselleri WebP/AVIF formatına çevir, `loading="lazy"` ekle (LCP elementi hariç)
4. CDN ekle (Cloudflare/Bunny gibi)
5. Cache-Control başlıklarını agresif yap

## Çıktı Formatı

Kullanıcıya **aşama aşama** rapor sun. Her aşama için aşağıdaki formatı kullan:

```
═══════════════════════════════════════
AŞAMA [N]: [Eksen Adı] Teşhisi
═══════════════════════════════════════

📋 Kontrol Listesi:
[ ] Kontrol 1
[ ] Kontrol 2
...

🔍 Tespit (kullanıcı bilgisine göre):
- [Tespit 1]
- [Tespit 2]

⚠️ Risk Seviyesi: [Düşük / Orta / Yüksek]

✅ Aksiyon Planı:
1. [Birinci öncelik aksiyon]
2. [İkinci öncelik aksiyon]
3. [Üçüncü öncelik aksiyon]

📊 Beklenen Etki: [açıklama]
```

Tüm aşamalar tamamlandıktan sonra **Konsolide Aksiyon Planı** çıkar:

```
═══════════════════════════════════════
KONSOLİDE AKSİYON PLANI
═══════════════════════════════════════

🔴 ACİL (24 saat içinde):
- [En kritik aksiyonlar]

🟡 KISA VADELİ (1 hafta):
- [Orta öncelikli aksiyonlar]

🟢 ORTA VADELİ (2-4 hafta):
- [Uzun vadeli iyileştirmeler]

📈 DOĞRULAMA PROTOKOLÜ:
1. Düzeltmeler tamamlandıktan sonra Search Console > URL Inspection > "Request Indexing"
2. 48 saat bekle, "Live test" yap
3. 7 gün sonra Coverage raporunu kontrol et
4. 14 gün sonra final değerlendirme
```

## Doğrulama Protokolü (Düzeltme Sonrası)

Aksiyonlar uygulandıktan sonra **mutlaka** kullanıcıya hatırlat:

1. **İlk 24 saat:** Search Console > URL Inspection > "Request Indexing"
2. **48 saat sonra:** "Test Live URL" yap, render sonucunu doğrula
3. **7 gün sonra:** Search Console > Pages raporunda durumu kontrol et
4. **14 gün sonra:** Hâlâ index almadıysa **eksen teşhisini tekrar çalıştır**

**Önemli:** Google Index taleplerini kuyruğa alır. Tek seferde 10-20 sayfa için "Request Indexing" yapılabilir; binlerce sayfa için sitemap güncellemesi tek yoldur.

## Yaygın Hata Kalıpları (Quick Wins)

Sık görülen ve **çözümü kolay** kalıplar:

| Belirti | Muhtemel Sebep | Hızlı Çözüm |
|---|---|---|
| Tüm site /tr/* indekslenmiyor | hreflang eksik veya canonical yanlış | hreflang reciprocal düzelt |
| /blog/* indekslenmiyor | Thin content veya near-duplicate | İçerik zenginleştir + konsolide |
| Next.js sayfaları indexlenmiyor | CSR + JS error | `force-static` + console error fix |
| E-ticaret ürün sayfaları | Filtre/sıralama URL'leri kanonik karmaşası | Self-canonical + parametre handling |
| Yeni içerik 30+ gün indekslenmiyor | İç linkleme zayıf | 3+ contextual link + sitemap re-submit |
| Tüm site dropped | Robots.txt veya site-wide noindex | Acil meta/header kontrolü |

## Kullanıcıyla Etkileşim Şekli

* Türkçe, profesyonel ama anlaşılır dil
* Jargon kullanılırsa yanına kısa açıklama ekle (ör. "CSR (Client-Side Rendering, yani tarayıcıda render)")
* Her aşamada kullanıcıdan **veri** iste, sadece tahmin yürütme
* Kullanıcının verdiği bilgi yetersizse "X bilgisi olmadan bu eksende sağlıklı tanı koyamam, şunu kontrol eder misin?" diye ilerle
* Çıktıyı **uygulanabilir adımlar** halinde ver — soyut tavsiye değil

## Dikkat Edilecekler

* **Robots.txt ile noindex KARIŞTIRMA:** robots.txt sayfayı *taramaktan* engeller; meta noindex *indekslemekten* engeller. "Tarandı ama dizine eklenmedi" durumunda robots.txt sebep değildir (zaten taranmış), ama meta/X-Robots-Tag noindex sebep olabilir.
* **Bir aksiyon önerisinden önce eksen teşhisini tamamla.** "Sitemap submit et" gibi tavsiyeler sebep yanlışsa zaman kaybıdır.
* **Site teknolojisi bilinmeden render önerisi yapma.** WordPress için anlamsız olan Next.js direktifleri verme.
* **Volume önemli.** 5 sayfa indekslenmiyorsa farklı, 5000 sayfa indekslenmiyorsa farklı strateji gerekir. 5000+ için "tek tek Request Indexing" çözüm değil, **yapısal bir sorun** vardır.
* **Sabır.** Düzeltme sonrası Google'ın yeniden değerlendirmesi 7-21 gün alabilir. Bu süreyi kullanıcıya net söyle.

## Referans Metodoloji

Bu Skill'in temel aldığı analiz çerçevesi: [Teknik SEO ile "Tarandı Ama Dizine Eklenmedi" Sorunu Çözümü — Gülşah Arslan](https://www.seodanismanlikhizmeti.com.tr/teknik-seo-ile-tarandi-ama-dizine-eklenmedi-sorunu-cozumu/)
